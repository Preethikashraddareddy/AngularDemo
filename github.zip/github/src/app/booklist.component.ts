import { Component,OnInit } from '@angular/core';
import {IBooklist} from './booklist';
import {BooklistService} from './booklist.service'

@Component({
  selector: 'my-app',
  templateUrl: './booklist.html',
   providers:[BooklistService]
})
export class BooklistComponent implements  OnInit {

 book:IBooklist[];
constructor(private bookservice:BooklistService) {}
ngOnInit(): void {
    this.bookservice.getAllBookList().subscribe((bookData)=>this.book=bookData);
}



}