import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<div><ul>
                            <li><a routerLink="search">Search</a></li>
                          </ul>
                      <router-outlet></router-outlet>  </div>`
})
export class AppComponent {
        
    
        }