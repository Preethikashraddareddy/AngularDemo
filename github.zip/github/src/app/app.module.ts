import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import {BooklistComponent }  from './booklist.component';
import {SearchBookComponent} from './searchbook.component';
import {HttpModule} from '@angular/http';
import {Routes, RouterModule} from '@angular/router';

const appRoutes: Routes=[
                     { path: '',  redirectTo:'/getdata',pathMatch: 'full'},
                     { path: 'getdata',  component:BooklistComponent }
                     {path:'search',component:EmployeeSearchComponent}
                      ];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(appRoutes)  ],
  declarations: [ AppComponent,BooklistComponent,SearchBookComponent],
  bootstrap:    [AppComponent  ]
})
export class AppModule { }
