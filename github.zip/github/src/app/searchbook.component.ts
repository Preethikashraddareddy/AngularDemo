import { Component,OnInit } from '@angular/core';
import {IBooklist} from './booklist';
import {BooklistService} from './booklist.service'

@Component({
    
  templateUrl: './booksearch.html',
   providers:[BooklistService]
})
export class SearchBookComponent implements  OnInit {

 book:IBooklist[];
constructor(private bookservice:BooklistService) {}
ngOnInit(): void {
    this.bookservice.getAllBookList().subscribe((bookData)=>this.book=bookData);
}
 id:any="";
searchData():void{
    this.bookservice.searchbook(this.id).subscribe((bookData)=>this.book=bookData);



}

}